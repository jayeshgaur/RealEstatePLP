export class UserModel{
    userId:any;
    userPassword:any;
    userName:any;
    userContact:any;
    userRole:any;
    userEmail:any;
    birthDate:any;
}