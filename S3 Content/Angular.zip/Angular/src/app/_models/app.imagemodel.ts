export class ImageModel{
    imageId:any
    imageName:any
    imageType:any
    url:any
    data:any




}