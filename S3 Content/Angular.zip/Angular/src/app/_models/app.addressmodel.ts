export class AddressModel{
    addressLine:any
    city:any
    state:any
    pincode:any
}