import {Component} from '@angular/core';

@Component({
    selector:'forbidden',
    templateUrl:'../_html/app.error403.html'
})
export class Error403Component{

}