import {Component} from '@angular/core';

@Component({
    selector:'error404',
    templateUrl:'../_html/app.error404.html'
})

export class Error404Component{

}